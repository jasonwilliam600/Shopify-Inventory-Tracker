TSH Shopify catalog adapter — V2 OFFLINE REVIEW ONLY

Files:
 - shopify-catalog-contract.ts : stricter boolean pagination termination and cursor checks
 - shopify-catalog-provider.ts : injected authorized session transport, validation, timeouts,
   bounded transient retries, Retry-After support, GraphQL throttle metadata.

DO NOT INSTALL OR RUN YET. Authentication, live calls, imports and publishing are not authorized.

Critical unresolved blocker: The store is historically >42,000 variants. Shopify's 25,000
normal-pagination limit is NOT solved. This provider explicitly throws
LARGE_CATALOG_STRATEGY_REQUIRED before attempting to page such a catalog.

A complete import needs a separately approved supported large-catalog strategy,
for example Shopify read-only bulk query (separate authorization), or provably
complete non-overlapping filtered partitions and reconciliation of moving data.
Count equality alone does not prove identical records before and after import.

No runtime credentials are present. Existing shopify-readonly.ts is not included
because it must remain unchanged.

The provider must be reviewed and mocked, and catalog activation/import must stay
separate from retrieval. No database or Shopify writes are included.
