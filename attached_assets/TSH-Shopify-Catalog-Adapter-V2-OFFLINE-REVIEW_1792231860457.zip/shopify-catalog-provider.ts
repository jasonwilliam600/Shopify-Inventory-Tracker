/** READ-ONLY REVIEW DRAFT. NOT INSTALLED OR EXECUTED.
 * Authenticated transport is deliberately injected; this file does not mint tokens.
 * IMPORTANT: Shopify caps normal connection pagination at 25,000 resources.
 * Full >25K collection needs a separately approved partition/bulk design.
 */
import {
  validateCompleteCatalog,
  type CatalogReadPage,
  type CompleteCatalogEvidence,
  type ShopifyCatalogReadPort,
} from './shopify-catalog-contract.js';

const API_VERSION = '2026-07';
const LIMIT = 25_000;
const PAGE_SIZE = 100 as const;
const MAX_ATTEMPTS = 5;
const REQUEST_TIMEOUT_MS = 15_000;
const RETRIEVAL_DEADLINE_MS = 8 * 60_000;

type Obj = Record<string, unknown>;
type Throttle = CatalogReadPage['throttle'];
export type ReadOnlyTransport = (url: string, init: RequestInit) => Promise<Response>;

function object(input: unknown, field: string): Obj {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error(`INVALID_${field}`);
  return input as Obj;
}
function string(input: unknown, name: string): string {
  if (typeof input !== 'string') throw new Error(`INVALID_${name}`);
  return input;
}
function nullableString(input: unknown, name: string): string | null {
  if (input === null) return null;
  return string(input, name);
}
function array(input: unknown, name: string): unknown[] {
  if (!Array.isArray(input)) throw new Error(`INVALID_${name}`);
  return input;
}
function wait(ms: number, signal: AbortSignal): Promise<void> {
  if (signal.aborted) return Promise.reject(signal.reason ?? new Error('ABORTED'));
  return new Promise((resolve, reject) => {
    const done = () => { clearTimeout(timer); signal.removeEventListener('abort', abort); };
    const abort = () => { done(); reject(signal.reason ?? new Error('ABORTED')); };
    const timer = setTimeout(() => { done(); resolve(); }, ms);
    signal.addEventListener('abort', abort, { once: true });
  });
}
function retryAfterMs(header: string | null): number | null {
  if (!header) return null;
  const n = Number(header);
  if (Number.isFinite(n) && n >= 0) return n * 1000;
  const date = Date.parse(header);
  return Number.isFinite(date) ? Math.max(0, date - Date.now()) : null;
}
function throttleFrom(input: unknown): Throttle {
  if (input === undefined) return null;
  const ext = object(input, 'EXTENSIONS');
  if (ext.cost === undefined) return null;
  const cost = object(ext.cost, 'COST');
  const status = object(cost.throttleStatus, 'THROTTLE_STATUS');
  const available = status.currentlyAvailable;
  const rate = status.restoreRate;
  const requested = cost.requestedQueryCost;
  if (typeof available !== 'number' || !Number.isFinite(available) ||
      typeof rate !== 'number' || !Number.isFinite(rate) || rate <= 0 ||
      typeof requested !== 'number' || !Number.isFinite(requested) || requested < 0) throw new Error('INVALID_THROTTLE_METADATA');
  return { currentlyAvailable: available, restoreRate: rate, requestedCost: requested };
}

export class ReadOnlyShopifyCatalogProvider implements ShopifyCatalogReadPort {
  private verifiedAt: string | null = null;
  private deadline = Infinity;
  private previousThrottle: Throttle = null;
  private constructor(private readonly shopDomain: string, private readonly accessToken: string, private readonly transport: ReadOnlyTransport) {}
  /** Accept only an ALREADY-AUTHORIZED token from a permitted integration. No token acquisition. */
  static fromAuthorizedSession(shop: string, accessToken: string, transport: ReadOnlyTransport = fetch): ReadOnlyShopifyCatalogProvider {
    if (!/^[a-z0-9][a-z0-9-]*\.myshopify\.com$/.test(shop)) throw new Error('INVALID_SHOP');
    if (!accessToken) throw new Error('MISSING_SESSION');
    return new ReadOnlyShopifyCatalogProvider(shop, accessToken, transport);
  }
  private async query(query: string, variables: Obj, signal: AbortSignal): Promise<{ data: Obj; throttle: Throttle }> {
    for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
      if (signal.aborted) throw signal.reason ?? new Error('ABORTED');
      if (Date.now() >= this.deadline) throw new Error('CATALOG_DEADLINE_EXCEEDED');
      if (this.previousThrottle && this.previousThrottle.currentlyAvailable < this.previousThrottle.requestedCost) {
        const t = this.previousThrottle;
        await wait(Math.ceil((t.requestedCost - t.currentlyAvailable) / t.restoreRate * 1000), signal);
      }
      const controller = new AbortController();
      const onAbort = () => controller.abort(signal.reason);
      signal.addEventListener('abort', onAbort, { once: true });
      const remaining = Math.min(REQUEST_TIMEOUT_MS, this.deadline - Date.now());
      const timeout = setTimeout(() => controller.abort(new Error('REQUEST_TIMEOUT')), Math.max(1, remaining));
      let retry = false;
      let hint: number | null = null;
      try {
        const response = await this.transport(`https://${this.shopDomain}/admin/api/${API_VERSION}/graphql.json`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-Shopify-Access-Token': this.accessToken },
          body: JSON.stringify({ query, variables }), signal: controller.signal,
        });
        if (response.status === 429 || response.status >= 500) {
          retry = true;
          hint = retryAfterMs(response.headers.get('retry-after'));
        } else {
          if (!response.ok) throw new Error(`SHOPIFY_HTTP_${response.status}`);
          const raw = object(await response.json(), 'GRAPHQL_RESPONSE');
          const errors = raw.errors;
          if (errors !== undefined) {
            if (!Array.isArray(errors)) throw new Error('INVALID_GRAPHQL_ERRORS');
            if (errors.length) {
              const codes = errors.map(e => object(e, 'GRAPHQL_ERROR')).map(e => {
                const ext = e.extensions === undefined ? {} : object(e.extensions, 'ERROR_EXTENSIONS');
                return ext.code;
              });
              retry = codes.every(c => c === 'THROTTLED');
              if (!retry) throw new Error('SHOPIFY_GRAPHQL_ERRORS');
            }
          }
          if (!retry) {
            const data = object(raw.data, 'GRAPHQL_DATA');
            const throttle = throttleFrom(raw.extensions);
            this.previousThrottle = throttle;
            return { data, throttle };
          }
        }
      } catch (err) {
        if (signal.aborted) throw err;
        if (controller.signal.aborted && (controller.signal.reason as Error)?.message !== 'REQUEST_TIMEOUT') throw err;
        if (err instanceof Error && !['REQUEST_TIMEOUT'].includes(err.message) && !/fetch|network/i.test(err.message) && !controller.signal.aborted) throw err;
        retry = true;
      } finally {
        clearTimeout(timeout);
        signal.removeEventListener('abort', onAbort);
      }
      if (!retry || attempt === MAX_ATTEMPTS - 1) throw new Error('SHOPIFY_RETRY_EXHAUSTED');
      const jitter = Math.floor(Math.random() * 250);
      const backoff = hint ?? (750 * 2 ** attempt + jitter);
      if (backoff > this.deadline - Date.now()) throw new Error('CATALOG_DEADLINE_EXCEEDED');
      await wait(backoff, signal);
    }
    throw new Error('SHOPIFY_RETRY_EXHAUSTED');
  }
  async installationInfo(signal: AbortSignal) {
    const { data } = await this.query(`query TSHPreflight { shop { myshopifyDomain } currentAppInstallation { accessScopes { handle } } productVariantsCount(limit: null) { count precision } }`, {}, signal);
    const shop = object(data.shop, 'SHOP');
    if (shop.myshopifyDomain !== this.shopDomain) throw new Error('WRONG_SHOP');
    const installation = object(data.currentAppInstallation, 'INSTALLATION');
    const scopes = array(installation.accessScopes, 'SCOPES').map(v => string(object(v, 'SCOPE').handle, 'SCOPE_HANDLE'));
    if (!scopes.includes('read_products') && !scopes.includes('write_products')) throw new Error('PRODUCT_SCOPE_UNVERIFIED');
    const count = object(data.productVariantsCount, 'VARIANT_COUNT');
    if (count.precision !== 'EXACT' || !Number.isSafeInteger(count.count) || (count.count as number) < 0) throw new Error('VARIANT_COUNT_NOT_EXACT');
    return { shopDomain: this.shopDomain, scopes, expectedVariantCount: count.count as number };
  }
  async readPage(request: { after: string | null; first: 100; signal: AbortSignal }): Promise<CatalogReadPage> {
    if (request.first !== PAGE_SIZE || (request.after !== null && typeof request.after !== 'string')) throw new Error('INVALID_PAGE_ARGUMENTS');
    const { data, throttle } = await this.query(`query TSHCatalogPage($first: Int!, $after: String) {
      productVariants(first: $first, after: $after) { pageInfo { hasNextPage endCursor }
        nodes { id sku title selectedOptions { name value } inventoryItem { id } product { id title vendor status } }
      }
    }`, { first: PAGE_SIZE, after: request.after }, request.signal);
    const conn = object(data.productVariants, 'VARIANTS');
    const page = object(conn.pageInfo, 'PAGE_INFO');
    if (typeof page.hasNextPage !== 'boolean') throw new Error('INVALID_HAS_NEXT_PAGE');
    if (page.endCursor !== null && typeof page.endCursor !== 'string') throw new Error('INVALID_END_CURSOR');
    if (page.hasNextPage && (!page.endCursor || typeof page.endCursor !== 'string')) throw new Error('MISSING_END_CURSOR');
    const nodes = array(conn.nodes, 'NODES');
    if (nodes.length > PAGE_SIZE) throw new Error('OVERSIZED_PAGE');
    const verifiedAt = this.verifiedAt ?? new Date().toISOString();
    return { identities: nodes.map(node => {
      const v = object(node, 'VARIANT');
      const product = object(v.product, 'PARENT_PRODUCT');
      const options = array(v.selectedOptions, 'OPTIONS').map(option => {
        const o = object(option, 'OPTION');
        return { name: string(o.name, 'OPTION_NAME'), value: string(o.value, 'OPTION_VALUE') };
      });
      const item = v.inventoryItem === null ? null : object(v.inventoryItem, 'INVENTORY_ITEM');
      return { shopDomain: this.shopDomain,
        productId: string(product.id, 'PRODUCT_ID'), variantId: string(v.id, 'VARIANT_ID'),
        inventoryItemId: item ? string(item.id, 'INVENTORY_ITEM_ID') : null,
        sku: nullableString(v.sku, 'SKU'), productTitle: string(product.title, 'PRODUCT_TITLE'),
        variantTitle: string(v.title, 'VARIANT_TITLE'), vendor: nullableString(product.vendor, 'VENDOR'),
        options, productStatus: string(product.status, 'PRODUCT_STATUS') as 'ACTIVE'|'DRAFT'|'ARCHIVED', verifiedAt };
    }), pageInfo: { hasNextPage: page.hasNextPage, endCursor: page.endCursor as string | null }, throttle };
  }
  /** Read-only and in-memory. Hard-stops above 25k until a separate strategy is approved. */
  async retrieveAll(signal: AbortSignal): Promise<CompleteCatalogEvidence> {
    this.deadline = Date.now() + RETRIEVAL_DEADLINE_MS;
    this.verifiedAt = new Date().toISOString();
    this.previousThrottle = null;
    try {
      const before = await this.installationInfo(signal);
      if (before.expectedVariantCount > LIMIT) throw new Error('LARGE_CATALOG_STRATEGY_REQUIRED');
      const pages: CatalogReadPage[] = [];
      const cursors = new Set<string>();
      let after: string | null = null;
      let total = 0;
      while (true) {
        const page = await this.readPage({ after, first: PAGE_SIZE, signal });
        pages.push(page);
        total += page.identities.length;
        if (total > LIMIT) throw new Error('PAGINATION_LIMIT_EXCEEDED');
        if (!page.pageInfo.hasNextPage) break;
        if (!page.pageInfo.endCursor || cursors.has(page.pageInfo.endCursor)) throw new Error('NON_ADVANCING_CURSOR');
        cursors.add(page.pageInfo.endCursor);
        after = page.pageInfo.endCursor;
      }
      const afterCheck = await this.installationInfo(signal);
      if (before.expectedVariantCount !== afterCheck.expectedVariantCount) throw new Error('CATALOG_CHANGED_DURING_READ');
      if (before.scopes.join(',') !== afterCheck.scopes.join(',')) throw new Error('SCOPES_CHANGED_DURING_READ');
      const evidence: CompleteCatalogEvidence = { source: 'live_shopify', shopDomain: this.shopDomain,
        verifiedAt: this.verifiedAt, scopes: afterCheck.scopes, expectedVariantCount: afterCheck.expectedVariantCount, pages };
      validateCompleteCatalog(evidence);
      if (Date.now() >= this.deadline) throw new Error('CATALOG_DEADLINE_EXCEEDED');
      // Count equality is not an atomic snapshot. An approved importer MUST reconcile identities.
      return evidence;
    } finally { this.verifiedAt = null; this.deadline = Infinity; }
  }
}
