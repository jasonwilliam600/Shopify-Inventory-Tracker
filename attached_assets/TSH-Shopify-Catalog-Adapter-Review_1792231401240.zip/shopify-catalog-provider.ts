/** Independent READ-ONLY Shopify catalog provider for API version 2026-07.
 * Prepared for review; NOT connected to routes, scheduled, or run automatically.
 * No Shopify mutations and no database writes.
 */
import type { CatalogReadPage, CompleteCatalogEvidence, ShopifyCatalogReadPort } from './shopify-catalog-contract.js';

const VERSION = '2026-07';
const SHOP_PATTERN = /^[a-z0-9][a-z0-9-]*\.myshopify\.com$/;

type JsonObject = Record<string, any>;
const wait = (ms: number, signal?: AbortSignal) => new Promise<void>((resolve, reject) => {
  if (signal?.aborted) return reject(signal.reason);
  const timer = setTimeout(() => { signal?.removeEventListener('abort', aborted); resolve(); }, ms);
  const aborted = () => { clearTimeout(timer); reject(signal?.reason ?? new Error('ABORTED')); };
  signal?.addEventListener('abort', aborted, { once: true });
});

function expectObject(value: unknown, name: string): JsonObject {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error(`INVALID_${name}`);
  return value as JsonObject;
}

export class ReadOnlyShopifyCatalogProvider implements ShopifyCatalogReadPort {
  private constructor(private readonly shop: string, private readonly token: string, private readonly verifiedAt: string) {}

  /** Token acquisition matches existing shopify-readonly.ts but doesn't alter it. */
  static async connectFromEnvironment(signal?: AbortSignal): Promise<ReadOnlyShopifyCatalogProvider> {
    const shop = (process.env.SHOPIFY_SHOP ?? '').trim().replace(/^https?:\/\//i, '').replace(/\.myshopify\.com\/?$/i, '').replace(/\/$/, '').toLowerCase() + '.myshopify.com';
    if (!SHOP_PATTERN.test(shop)) throw new Error('INVALID_SHOP_IDENTITY');
    const id = process.env.SHOPIFY_CLIENT_ID;
    const secret = process.env.SHOPIFY_CLIENT_SECRET;
    if (!id || !secret) throw new Error('MISSING_SHOPIFY_CREDENTIALS');
    const response = await fetch(`https://${shop}/admin/oauth/access_token`, {
      method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
      body: new URLSearchParams({ grant_type: 'client_credentials', client_id: id, client_secret: secret }), signal,
    });
    if (!response.ok) throw new Error(`SHOPIFY_TOKEN_HTTP_${response.status}`);
    const payload = expectObject(await response.json(), 'TOKEN_RESPONSE');
    if (typeof payload.access_token !== 'string' || !payload.access_token) throw new Error('MISSING_ACCESS_TOKEN');
    return new ReadOnlyShopifyCatalogProvider(shop, payload.access_token, new Date().toISOString());
  }

  private async query<T extends JsonObject>(query: string, variables: JsonObject = {}, signal?: AbortSignal): Promise<T> {
    for (let attempt = 0; attempt < 5; attempt++) {
      const response = await fetch(`https://${this.shop}/admin/api/${VERSION}/graphql.json`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Shopify-Access-Token': this.token },
        body: JSON.stringify({ query, variables }), signal,
      });
      if (response.status === 429 || response.status >= 500) {
        if (attempt === 4) throw new Error(`SHOPIFY_HTTP_${response.status}`);
        const retryAfter = Number(response.headers.get('retry-after'));
        await wait(Number.isFinite(retryAfter) && retryAfter > 0 ? Math.min(retryAfter * 1000, 10000) : 600 * 2 ** attempt, signal);
        continue;
      }
      if (!response.ok) throw new Error(`SHOPIFY_HTTP_${response.status}`);
      const payload = expectObject(await response.json(), 'GRAPHQL_RESPONSE');
      if (Array.isArray(payload.errors) && payload.errors.length) {
        if (payload.errors.some((e: JsonObject) => e?.extensions?.code === 'THROTTLED') && attempt < 4) {
          await wait(600 * 2 ** attempt, signal);
          continue;
        }
        throw new Error('SHOPIFY_GRAPHQL_ERRORS');
      }
      if (!payload.data) throw new Error('SHOPIFY_GRAPHQL_MISSING_DATA');
      return payload.data as T;
    }
    throw new Error('SHOPIFY_RETRIES_EXHAUSTED');
  }

  async installationInfo(signal?: AbortSignal): Promise<{ shopDomain: string; scopes: string[]; expectedVariantCount: number }> {
    const data = await this.query<JsonObject>(`query TSHCatalogPreflight {
      shop { myshopifyDomain }
      currentAppInstallation { accessScopes { handle } }
      productVariantsCount(limit: null) { count precision }
    }`, {}, signal);
    if (data.shop?.myshopifyDomain?.toLowerCase() !== this.shop) throw new Error('WRONG_SHOP');
    const scopes: unknown[] = data.currentAppInstallation?.accessScopes?.map((x: JsonObject) => x.handle) ?? [];
    if (!scopes.every(s => typeof s === 'string')) throw new Error('INVALID_SCOPES');
    if (!scopes.includes('read_products') && !scopes.includes('write_products')) throw new Error('PRODUCT_SCOPE_UNVERIFIED');
    const count = data.productVariantsCount;
    if (count?.precision !== 'EXACT' || !Number.isSafeInteger(count?.count) || count.count < 0) throw new Error('VARIANT_COUNT_NOT_EXACT');
    return { shopDomain: this.shop, scopes: scopes as string[], expectedVariantCount: count.count };
  }

  async readPage(request: { after: string | null; first: 100; signal: AbortSignal }): Promise<CatalogReadPage> {
    const result = await this.query<JsonObject>(`query TSHCatalogPage($first: Int!, $after: String) {
      productVariants(first: $first, after: $after) {
        pageInfo { hasNextPage endCursor }
        nodes {
          id sku title selectedOptions { name value }
          inventoryItem { id }
          product { id title vendor status }
        }
      }
    }`, { first: request.first, after: request.after }, request.signal);
    const conn = result.productVariants;
    if (!conn || !Array.isArray(conn.nodes) || !conn.pageInfo) throw new Error('INVALID_VARIANT_PAGE');
    return {
      identities: conn.nodes.map((v: JsonObject) => ({
        shopDomain: this.shop, productId: v.product?.id, variantId: v.id,
        inventoryItemId: v.inventoryItem?.id ?? null, sku: v.sku ?? null,
        productTitle: v.product?.title, variantTitle: v.title,
        vendor: v.product?.vendor ?? null, options: v.selectedOptions,
        productStatus: v.product?.status, verifiedAt: this.verifiedAt,
      })),
      pageInfo: conn.pageInfo,
      throttle: null, // Throttle information is in extensions, which this transport does not expose.
    };
  }

  /** In-memory only: callers must separately validate via validateCompleteCatalog. */
  async retrieveAll(signal: AbortSignal): Promise<CompleteCatalogEvidence> {
    const preflight = await this.installationInfo(signal);
    const pages: CatalogReadPage[] = [];
    let after: string | null = null;
    const seen = new Set<string>();
    do {
      const page = await this.readPage({ after, first: 100, signal });
      pages.push(page);
      if (!page.pageInfo.hasNextPage) break;
      if (!page.pageInfo.endCursor || seen.has(page.pageInfo.endCursor)) throw new Error('NON_ADVANCING_CURSOR');
      seen.add(page.pageInfo.endCursor);
      after = page.pageInfo.endCursor;
      if (pages.length > 10000) throw new Error('PAGE_LIMIT_EXCEEDED');
    } while (true);
    const end = await this.installationInfo(signal);
    if (end.expectedVariantCount !== preflight.expectedVariantCount) throw new Error('CATALOG_CHANGED_DURING_READ');
    return { source: 'live_shopify', shopDomain: this.shop, verifiedAt: this.verifiedAt,
      scopes: end.scopes, expectedVariantCount: end.expectedVariantCount, pages };
  }
}
