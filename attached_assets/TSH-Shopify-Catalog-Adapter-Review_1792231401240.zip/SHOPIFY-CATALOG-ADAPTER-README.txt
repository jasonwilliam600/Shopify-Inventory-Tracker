TOP SPEED INVENTORY SYNC — Read-only Shopify catalog provider (prepared; NOT installed)

Files
- shopify-catalog-provider.ts : NEW proposed transport/provider implementation
- shopify-catalog-contract.ts : UNCHANGED user-supplied interface for reference
- shopify-readonly.ts : UNCHANGED user-supplied existing connectivity helper for reference

Recommended target for the NEW file:
artifacts/api-server/src/lib/shopify-catalog-provider.ts

What the new provider does:
- Uses the established client-credentials token endpoint with the existing environment variables, only when called explicitly.
- Checks installed app granted scopes and the expected shop domain.
- Requests exact variant count with productVariantsCount(limit: null).
- Reads Shopify productVariants in pages of 100 and maps into the provided catalog contract.
- Stops on API errors, count changes, bad pagination, or missing permissions.
- Returns only in-memory records; no database or Shopify writes.

What has NOT been done:
- No network authentication, requests, secrets inspection, or live import.
- No changes to shopify-readonly.ts, app routes, database, supplier workers, or deployed project.
- No full build in the original project was possible from only the two supplied files.
- The provider's identity/count read cannot guarantee an atomic Shopify catalog snapshot if the catalog changes while paging; validate and reconcile before activating data.
- The GraphQL throttle metadata property is null; production hardening should propagate response.extensions.cost.throttleStatus and obey retry hints.
- Reviewer authentication, approval API, and catalog importer are still absent.

Next step:
Have the NEW file and original contract reviewed together in the existing project. Run TypeScript checks and mocked Shopify GraphQL tests without making live requests or changing the current helper. Connect it to the catalog import workflow only after separate approval.
